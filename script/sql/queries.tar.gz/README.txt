- Export all global and national data from ORACLE db using the file 'oraclereports.sql' - without the limit of the year

- Make sure the values on the end of 'importing_global.sql' and 'importing_national.sql' match the years you want to import

- Use the file 'importing_global.sql' to import the global data
- Use the file 'importing_national.sql' to import the national data
- Use the file 'term_codes.sql' to update data
- Use the file 'origin_country_codes.sql' to update data