UPDATE national_trade_summaries SET origin_country_code = NULL WHERE origin_country_code = '';
UPDATE national_detail SET origin_country_code = NULL WHERE origin_country_code = '';
